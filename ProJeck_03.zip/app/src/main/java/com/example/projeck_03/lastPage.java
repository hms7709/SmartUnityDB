package com.example.projeck_03;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class lastPage extends AppCompatActivity {

    Button btn_1, btn_2, btn_3, btn_4; // 텝 메뉴

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_last_page);

        btn_1 = (Button)findViewById(R.id.btn_1);  // 지금 이곳이 홈이라는 알림표시
        btn_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(lastPage.this,MainActivity.class);
                startActivity(intent);
            }
        });
        btn_2 = (Button)findViewById(R.id.btn_2);
        btn_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(lastPage.this,sencer.class);
                startActivity(intent);
            }
        });
        btn_3 = (Button)findViewById(R.id.btn_3);
        btn_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(lastPage.this,Window.class);
                startActivity(intent);
            }
        });
        btn_4 = (Button)findViewById(R.id.btn_4);
        btn_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"지금 이곳이 last page 입니다.",Toast.LENGTH_SHORT).show();
            }
        });
    }
}
